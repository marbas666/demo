
jquery.min.js
qrcode.min.js

上記のファイルは、以下のURLから取得したJavaScriptです。
ライセンスは取得元に依存します。
https://davidshimjs.github.io/qrcodejs/